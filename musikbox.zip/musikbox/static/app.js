/* ==========================================================================
   MUSIKBOX — Lecteur multimédia (style Spotify)
   Recherche sons & vidéos · lecture · playlists intelligentes · téléchargements
   ========================================================================== */
"use strict";

/* ----------------------------- Utilitaires ------------------------------ */
const $ = (sel, el = document) => el.querySelector(sel);
const $$ = (sel, el = document) => [...el.querySelectorAll(sel)];

function esc(s) {
  return String(s ?? "").replace(/[&<>"']/g, c => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[c]);
}

const b64url = s => btoa(unescape(encodeURIComponent(s))).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");

async function api(path, opts = {}) {
  const res = await fetch(path, opts);
  if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error || "Erreur " + res.status);
  return res.json();
}

function fmtTime(sec) {
  if (!isFinite(sec) || sec < 0) return "0:00";
  sec = Math.round(sec);
  const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = sec % 60;
  return h ? `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}` : `${m}:${String(s).padStart(2, "0")}`;
}

const fmtSize = n => n >= 1 << 30 ? (n / (1 << 30)).toFixed(2) + " Go"
  : n >= 1 << 20 ? (n / (1 << 20)).toFixed(1) + " Mo"
  : n >= 1 << 10 ? Math.round(n / (1 << 10)) + " Ko" : n + " o";

const PLACEHOLDER = `data:image/svg+xml;utf8,${encodeURIComponent(
  `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 160 100">
    <defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="#3a2613"/><stop offset="1" stop-color="#17100a"/>
    </linearGradient></defs>
    <rect width="160" height="100" fill="url(#g)"/>
    <circle cx="80" cy="50" r="26" fill="#241708" stroke="#8a5a2b" stroke-width="2"/>
    <circle cx="80" cy="50" r="8" fill="#d9a962"/><circle cx="80" cy="50" r="3" fill="#17100a"/>
  </svg>`)}`;

function thumbImg(src, cls = "") {
  const img = document.createElement("img");
  img.loading = "lazy"; img.alt = ""; img.className = cls;
  img.src = src || PLACEHOLDER;
  img.onerror = () => { img.src = PLACEHOLDER; };
  return img;
}

function artistOf(title) {
  const t = String(title || "");
  const i = t.search(/\s[-–—]\s/);
  return i > 0 ? t.slice(0, i).trim() : "";
}

/* ------------------------------- Toasts ---------------------------------- */
function toast(msg, type = "ok", ms = 3800) {
  const el = document.createElement("div");
  el.className = "toast " + type;
  el.textContent = msg;
  $("#toasts").appendChild(el);
  setTimeout(() => { el.classList.add("leaving"); setTimeout(() => el.remove(), 320); }, ms);
}

/* ------------------------- Persistance navigateur ------------------------ */
const LS = {
  get(k, d) { try { return JSON.parse(localStorage.getItem("musikbox." + k)) ?? d; } catch (e) { return d; } },
  set(k, v) { localStorage.setItem("musikbox." + k, JSON.stringify(v)); },
};

let favorites = LS.get("favs", []);
let history = LS.get("history", []);
let customPlaylists = LS.get("playlists", {});   // {nom: [track, ...]}

function saveFavs() { LS.set("favs", favorites); }
function isFav(key) { return favorites.some(f => f.key === key); }
function toggleFav(track) {
  const i = favorites.findIndex(f => f.key === track.key);
  if (i >= 0) { favorites.splice(i, 1); toast("Retiré des favoris"); }
  else { favorites.push(track); toast("Ajouté aux favoris ♥"); }
  saveFavs(); updatePlayerUi(); renderNavCounts();
}

function notePlay(t) {
  const rec = history.find(x => x.key === t.key);
  if (rec) { rec.ts = Date.now(); rec.count = (rec.count || 0) + 1; }
  else history.unshift({ key: t.key, title: t.title, thumb: t.thumb,
    duration: t.duration || 0, duration_str: t.duration_str || "",
    url: t.url || "", name: t.name || "", local: !!t.local,
    payload: t.payload || "", count: 1, ts: Date.now() });
  LS.set("history", history.slice(0, 120));
}

function playlistNames() { return Object.keys(customPlaylists); }
function toggleInPlaylist(name, track) {
  const list = customPlaylists[name] || [];
  const i = list.findIndex(t => t.key === track.key);
  if (i >= 0) { list.splice(i, 1); toast(`Retiré de « ${name} »`); }
  else { list.push({ key: track.key, title: track.title, thumb: track.thumb,
    duration: track.duration, duration_str: track.duration_str,
    url: track.url || "", name: track.name || "" }); toast(`Ajouté à « ${name} » ♪`); }
  if (list.length) customPlaylists[name] = list;
  else delete customPlaylists[name];
  LS.set("playlists", customPlaylists);
}

/* ----------------------------- Routeur ----------------------------------- */
let currentQuery = "";
let lastGenre = "";

function parseHash() {
  const h = location.hash.replace(/^#\/?/, "");
  const [path, qs] = h.split("?");
  const params = new URLSearchParams(qs || "");
  return { path: path || "home", params };
}

function renderNavCounts() {
  $("#lib-count").textContent = libraryItems.length;
  $("#fav-count").textContent = favorites.length;
  $("#dl-count").hidden = !activeJobsCount();
  $("#dl-count").textContent = activeJobsCount();
}
function activeJobsCount() {
  return Object.values(activeJobs).filter(j => ["queued", "downloading"].includes(j.status)).length;
}

window.addEventListener("hashchange", () => render());
document.addEventListener("click", e => {
  if (e.target.closest(".burger")) return;
  const sb = $("#sidebar");
  if (sb.classList.contains("open") && !e.target.closest("#sidebar")) sb.classList.remove("open");
});

function render() {
  const { path, params } = parseHash();
  const view = $("#view");
  $$(".side-nav a").forEach(a => a.classList.toggle("active", a.dataset.nav === path));
  view.innerHTML = "";
  if (path === "home") renderHome(view);
  else if (path === "recherche") renderSearch(view, params.get("q") || currentQuery, params.get("page") || "1", params.get("tab") || "tout");
  else if (path === "bibliotheque") renderLibrary(view);
  else if (path === "favoris") renderFavs(view);
  else if (path === "playlists") renderPlaylists(view, params.get("p") || "");
  else if (path === "telechargements") renderDownloads(view);
  else { location.hash = "#/"; return; }
  window.scrollTo({ top: 0 });
  $("#sidebar").classList.remove("open");
}

/* ------------------------------ Données -------------------------------- */
let libraryItems = [];

function refreshLibrary() {
  return api("/api/library").then(r => {
    libraryItems = r.items || [];
    renderNavCounts();
    return libraryItems;
  }).catch(() => { libraryItems = []; renderNavCounts(); return []; });
}

/* ======================================================================
   ACCUEIL
   ====================================================================== */
const GENRES = [
  ["african", "Afro / Amapiano"], ["pop", "Pop"], ["hip-hop", "Hip-Hop / Rap"],
  ["rb-soul", "R&B / Soul"], ["reggae-caribbean", "Reggae / Dancehall"],
  ["dance-electronic", "Dance / Électro"], ["rock", "Rock"],
  ["latin", "Latino"], ["k-pop", "K-Pop"], ["j-pop", "J-Pop"],
  ["jazz", "Jazz"], ["gospel", "Gospel"], ["bollywood-indian", "Bollywood"],
  ["country-americana", "Country"], ["classical", "Classique"],
  ["soundtracks-musicals", "Bandes originales"], ["decades", "Années 80/90"],
];
const genreLabel = slug => (GENRES.find(g => g[0] === slug) || [slug, slug])[1];

function renderHome(view) {
  const last = history[0];
  view.innerHTML = `
    <section class="hero glass">
      <h1>Vos sons, <em>à portée de main.</em></h1>
      <p>Recherchez des sons et des vidéos, écoutez, téléchargez.
         Vos morceaux sauvegardés restent <strong>sur votre machine</strong>,
         dans votre bibliothèque locale.</p>
      <div class="hero-search">
        <div class="search glass-inset">
          <svg class="search-ico" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></svg>
          <input id="home-search" type="search" placeholder="Artiste, titre, vidéo, groupe…">
          <div id="home-suggest" class="suggest glass" hidden></div>
        </div>
        <button class="wood btn-wood" id="home-go">Rechercher</button>
      </div>
      <div class="section-title">Genres & ambiances</div>
      <div class="chips">
        ${GENRES.map(([slug, label]) => `<button class="chip" data-genre="${slug}">${esc(label)}</button>`).join("")}
      </div>
    </section>

    <div id="home-smart"></div>
    <div id="home-resume"></div>
    <div id="home-recent"></div>
    <h2 class="section-title">🔥 Tendances du moment</h2>
    <div id="top-grid"><div class="loader-wrap"><div class="spinner"></div><span>Chargement des tendances…</span></div></div>`;

  const input = $("#home-search"), sug = $("#home-suggest");
  input.addEventListener("input", () => suggest(input, sug));
  input.addEventListener("keydown", e => { if (e.key === "Enter") { e.preventDefault(); goSearch(input.value); } });
  $("#home-go").addEventListener("click", () => goSearch(input.value));
  $$(".chip", view).forEach(c => c.addEventListener("click", () => {
    currentQuery = "genre:" + c.dataset.genre;
    location.hash = "#/recherche?q=" + encodeURIComponent(currentQuery) + "&tab=playlists";
  }));

  // Playlists intelligentes
  $("#home-smart").innerHTML = `
    <h2 class="section-title">✨ Playlists intelligentes</h2>
    <div class="smart-grid">
      ${smartCard("💾", "Ma bibliothèque", "Tous vos MP3 téléchargés, en local.", "smart:library")}
      ${smartCard("🕘", "Récemment écoutés", "Reprenez là où vous vous êtes arrêté.", "smart:recent")}
      ${smartCard("🔥", "Plus écoutés", "Vos morceaux préférés, en boucle.", "smart:top")}
      ${smartCard("🎧", "Coups de cœur", "Tous vos favoris réunis.", "smart:favs")}
      ${smartCard("✨", "Découverte", "Un mélange des tendances du moment.", "smart:discover")}
      ${smartCard("🤝", "Similaires", "Des sons proches de ce que vous écoutez.", "smart:similar")}
    </div>`;
  $$("#home-smart .smart-card").forEach(c => c.addEventListener("click", () => {
    location.hash = "#/playlists?p=" + encodeURIComponent(c.dataset.smart);
  }));

  // Reprendre la lecture
  if (last) {
    $("#home-resume").innerHTML = `
      <h2 class="section-title">▶ Reprendre la lecture</h2>
      <div class="glass" style="padding:6px"><div class="trow" id="resume-row">
        <div class="art">${last.thumb ? `<img src="${esc(last.thumb)}" alt="" onerror="this.src='${PLACEHOLDER}'">` : ""}</div>
        <div class="row-meta"><div class="row-t">${esc(last.title)}</div><div class="row-s">${esc(last.duration_str || "")} · écouté ${new Date(last.ts).toLocaleString("fr-FR")}</div></div>
        <div class="row-side"><button class="wood btn-wood sm">▶ Reprendre</button></div>
      </div></div>`;
    $("#resume-row").addEventListener("click", () => playHistory(last));
  }

  // Récemment écoutés (autres)
  const recents = history.slice(1, 7);
  if (recents.length) {
    $("#home-recent").innerHTML = `
      <h2 class="section-title">🕘 Historique récent</h2>
      <div class="track-rows">${recents.map(t => trowHtml(t)).join("")}</div>`;
    bindTrows($("#home-recent"));
  }

  // Tendances
  api("/api/top").then(r => {
    const grid = $("#top-grid");
    if (!grid) return;
    if (!r.items || !r.items.length) { grid.innerHTML = `<div class="empty"><div class="big">🎵</div>Aucune tendance pour le moment.</div>`; return; }
    grid.className = "grid";
    grid.innerHTML = r.items.map(cardHtml).join("");
    bindCards(grid);
  }).catch(() => {
    const grid = $("#top-grid");
    if (grid) grid.innerHTML = `<div class="empty"><div class="big">😕</div>Impossible de charger les tendances.</div>`;
  });
}

function smartCard(ico, title, desc, smart) {
  return `<div class="smart-card glass" data-smart="${esc(smart)}">
    <div class="smart-ico">${ico}</div>
    <div><h3>${esc(title)}</h3><p>${esc(desc)}</p></div>
  </div>`;
}

function goSearch(q) {
  q = (q || "").trim();
  if (!q) return;
  currentQuery = q;
  location.hash = "#/recherche?q=" + encodeURIComponent(q) + "&tab=tout&page=1";
}

/* ======================================================================
   CARTES & RANGÉES
   ====================================================================== */
function cardHtml(t) {
  const isPlaylist = !!t.playlist;
  const artist = artistOf(t.title);
  return `
  <article class="card glass" data-url="${esc(t.url)}" data-playlist="${isPlaylist}">
    <div class="art">
      ${t.thumb ? `<img src="${esc(t.thumb)}" alt="" loading="lazy" onerror="this.src='${PLACEHOLDER}'">` : `<div style="width:100%;height:100%"></div>`}
      <span class="dur">${esc(t.duration_str || "0:00")}</span>
      <span class="play-fab">${isPlaylist
        ? `<svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M3 6h13v2H3zm0 5h13v2H3zm0 5h8v2H3zm14-7v8l6-4z"/></svg>`
        : `<svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>`}</span>
    </div>
    <h3>${esc(t.title)}</h3>
    <div class="sub">${isPlaylist ? "🎧 Playlist — cliquer pour voir" : esc(artist || "Écouter & télécharger")}</div>
  </article>`;
}

function bindCards(container) {
  $$(".card", container).forEach(card => {
    card.addEventListener("click", () => {
      if (card.dataset.playlist === "true") {
        lastGenre = currentQuery.startsWith("genre:") ? currentQuery : lastGenre;
        currentQuery = "playlist:" + card.dataset.url;
        location.hash = "#/recherche?q=" + encodeURIComponent(currentQuery) + "&tab=tout";
      } else {
        openDetail(card.dataset.url);
      }
    });
  });
}

function trowHtml(t, opts = {}) {
  const artist = artistOf(t.title);
  const dlName = getDownloaded()[t.key || ""] || t.name;
  const local = !!dlName;
  return `
  <div class="trow" data-key="${esc(t.key || "")}" data-url="${esc(t.url || "")}" data-name="${esc(t.name || "")}">
    <div class="art">${t.thumb ? `<img src="${esc(t.thumb)}" alt="" loading="lazy" onerror="this.src='${PLACEHOLDER}'">` : ""}</div>
    <div class="row-meta">
      <div class="row-t">${esc(t.title)}</div>
      <div class="row-s">${esc(artist || "—")} · ${esc(t.duration_str || "")} ${local ? '<span class="row-local">◉ local</span>' : '<span class="row-live">◌ streaming</span>'}</div>
    </div>
    <div class="row-side">
      ${opts.fav !== false ? `<button class="icon-btn row-fav" title="Favori">${isFav(t.key) ? "♥" : "♡"}</button>` : ""}
      ${opts.pl !== false ? `<button class="icon-btn row-pl" title="Ajouter à une playlist">＋</button>` : ""}
      <button class="wood btn-wood sm row-play">${opts.playing ? "⏸ Pause" : "▶ Écouter"}</button>
    </div>
  </div>`;
}

function bindTrows(container, list) {
  $$(".trow", container).forEach(row => {
    const t = (list || []).find(x => (x.key || "") === row.dataset.key) ||
      { key: row.dataset.key, url: row.dataset.url, name: row.dataset.name,
        title: $(".row-t", row)?.textContent };
    row.addEventListener("click", e => {
      if (e.target.closest(".row-fav") || e.target.closest(".row-pl") || e.target.closest(".row-play")) return;
      playTrackObject(t);
    });
    const playBtn = $(".row-play", row);
    if (playBtn) playBtn.addEventListener("click", e => {
      e.stopPropagation();
      const cur = currentTrack();
      if (cur && cur.key === t.key && !media.paused) { media.pause(); }
      else playTrackObject(t);
    });
    const favBtn = $(".row-fav", row);
    if (favBtn) favBtn.addEventListener("click", e => {
      e.stopPropagation();
      toggleFav({ key: t.key, title: t.title || row.dataset.key, thumb: t.thumb,
        duration: t.duration, duration_str: t.duration_str, url: t.url || "", name: t.name || "" });
      favBtn.textContent = isFav(t.key) ? "♥" : "♡";
    });
    const plBtn = $(".row-pl", row);
    if (plBtn) plBtn.addEventListener("click", e => {
      e.stopPropagation();
      const track = { key: t.key, title: t.title || row.dataset.key, thumb: t.thumb,
        duration: t.duration, duration_str: t.duration_str, url: t.url || "", name: t.name || "" };
      promptPlaylist(track);
    });
  });
}

/* ======================================================================
   RECHERCHE (avec onglets Tout / Sons / Vidéos)
   ====================================================================== */
const VIDEO_HINT = /(official\s*video|music\s*video|live|concert|clip|trailer|documentary|full\s*album|full\s*movie|performance)/i;

function isLikelyVideo(t) {
  return (t.duration >= 600) || VIDEO_HINT.test(t.title);
}

function renderSearch(view, q, pageStr, tab) {
  const page = parseInt(pageStr) || 1;
  const inPlaylist = q.startsWith("playlist:");
  const inGenre = q.startsWith("genre:");
  const display = inGenre ? genreLabel(q.slice(6)) : (inPlaylist ? "Playlist" : q);

  view.innerHTML = `
    <div class="tabs">
      ${inGenre ? `<button class="tab active" data-tab="playlists">🎧 Playlists du genre</button>` : inPlaylist ? "" : `
      <button class="tab ${tab === "tout" ? "active" : ""}" data-tab="tout">🎵 Tout</button>
      <button class="tab ${tab === "sons" ? "active" : ""}" data-tab="sons">🎶 Sons</button>
      <button class="tab ${tab === "videos" ? "active" : ""}" data-tab="videos">🎬 Vidéos</button>`}
    </div>
    <div class="hero glass" style="padding:22px 26px">
      <h1 style="font-size:1.45rem">${inPlaylist ? "🎧" : "Résultats pour"} <em>« ${esc(display)} »</em></h1>
      ${inPlaylist && lastGenre ? `<p style="color:var(--cream-dim);font-size:.85rem;margin-top:6px"><a href="#/recherche?q=${encodeURIComponent(lastGenre)}&tab=playlists">↩ Retour aux playlists</a></p>` : ""}
      <div id="search-grid"><div class="loader-wrap"><div class="spinner"></div><span>Recherche en cours…</span></div></div>
      <div class="pager" id="pager"></div>
    </div>`;

  $$(".tab", view).forEach(t => t.addEventListener("click", () => {
    const params = new URLSearchParams(location.hash.split("?")[1] || "");
    location.hash = `#/recherche?q=${encodeURIComponent(q)}&tab=${t.dataset.tab}&page=1`;
  }));

  const grid = $("#search-grid");
  api(`/api/search?q=${encodeURIComponent(q)}&page=${page}`).then(r => {
    let items = r.items || [];
    if (!inGenre && !r.playlists && !r.playlist) {
      if (tab === "sons") items = items.filter(t => !isLikelyVideo(t));
      else if (tab === "videos") items = items.filter(t => isLikelyVideo(t));
    }
    if (!items.length) {
      grid.className = "";
      grid.innerHTML = `<div class="empty"><div class="big">🔍</div>Aucun résultat pour « ${esc(display)} ».<br><span style="font-size:.85rem;color:var(--cream-faint)">Essayez un autre titre, ou explorez les genres depuis l'accueil.</span></div>`;
      return;
    }
    grid.className = "grid";
    grid.innerHTML = items.map(cardHtml).join("");
    bindCards(grid);
    const pager = $("#pager");
    if (page > 1) {
      const prev = document.createElement("button");
      prev.className = "ghost"; prev.textContent = "← Page précédente";
      prev.onclick = () => { location.hash = `#/recherche?q=${encodeURIComponent(q)}&tab=${tab}&page=${page - 1}`; };
      pager.appendChild(prev);
    }
    if (r.has_more && !r.playlists && !r.playlist) {
      const next = document.createElement("button");
      next.className = "wood btn-wood sm"; next.textContent = "Page suivante →";
      next.onclick = () => { location.hash = `#/recherche?q=${encodeURIComponent(q)}&tab=${tab}&page=${page + 1}`; };
      pager.appendChild(next);
    }
  }).catch(e => {
    grid.className = "";
    grid.innerHTML = `<div class="empty"><div class="big">⚠️</div>Erreur de recherche : ${esc(e.message)}</div>`;
  });
}

/* ======================================================================
   BIBLIOTHÈQUE LOCALE
   ====================================================================== */
function renderLibrary(view) {
  view.innerHTML = `
    <h2 class="section-title">💾 Ma bibliothèque</h2>
    <div class="dl-stat-cards">
      <div class="dl-stat glass"><div class="n" id="st-nb">0</div><div class="l">Fichiers</div></div>
      <div class="dl-stat glass"><div class="n" id="st-size">0</div><div class="l">Espace local</div></div>
      <div class="dl-stat glass"><div class="n" id="st-dur">0:00</div><div class="l">Durée totale</div></div>
    </div>
    <div class="glass" style="padding:6px;margin-bottom:14px">
      <div class="trow" style="cursor:default">
        <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" style="color:var(--cream-faint)"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></svg>
        <input id="lib-filter" type="search" placeholder="Filtrer ma bibliothèque…" style="flex:1;background:none;border:none;outline:none;color:var(--cream);font-size:.92rem">
        <select id="lib-sort" style="background:rgba(20,13,6,.5);border:1px solid var(--glass-border);color:var(--cream);border-radius:999px;padding:7px 12px;font-size:.8rem;outline:none">
          <option value="added">Récemment ajoutés</option>
          <option value="title">Titre A→Z</option>
          <option value="artist">Artiste</option>
          <option value="size">Taille</option>
        </select>
      </div>
    </div>
    <div id="lib-list"></div>`;

  refreshLibrary().then(items => {
    drawLibrary($("#lib-list"), items);
    $("#lib-filter").addEventListener("input", e => applyLibFilter());
    $("#lib-sort").addEventListener("change", () => applyLibFilter());
  });
}

function applyLibFilter() {
  const f = ($("#lib-filter")?.value || "").toLowerCase();
  const sort = $("#lib-sort")?.value || "added";
  let items = [...libraryItems];
  if (f) items = items.filter(i => i.title.toLowerCase().includes(f) || i.name.toLowerCase().includes(f));
  if (sort === "title") items.sort((a, b) => a.title.localeCompare(b.title, "fr"));
  else if (sort === "artist") items.sort((a, b) => artistOf(a.title).localeCompare(artistOf(b.title), "fr"));
  else if (sort === "size") items.sort((a, b) => b.size - a.size);
  drawLibrary($("#lib-list"), items);
}

function drawLibrary(el, items) {
  if (!items.length) {
    el.innerHTML = `<div class="empty glass"><div class="big">💿</div>Votre bibliothèque est vide.<br>
      <span style="font-size:.85rem;color:var(--cream-faint)">Cherchez un morceau, puis cliquez sur « Télécharger » pour le garder ici.</span></div>`;
    return;
  }
  el.innerHTML = `<div class="track-rows">` + items.map(it => trowHtml({
    key: it.url || "local:" + it.name, title: it.title, thumb: it.thumb,
    duration: it.duration, duration_str: it.duration_str, name: it.name, url: it.url || "",
  }, { fav: false })).join("") + `</div>`;
  bindTrows(el, items.map(it => ({
    key: it.url || "local:" + it.name, title: it.title, thumb: it.thumb,
    duration: it.duration, duration_str: it.duration_str, name: it.name, url: it.url || "", local: true,
  })));

  const totalSize = libraryItems.reduce((s, i) => s + (i.size || 0), 0);
  const totalDur = libraryItems.reduce((s, i) => s + (i.duration || 0), 0);
  const nb = $("#st-nb"); if (nb) nb.textContent = items.length;
  const sz = $("#st-size"); if (sz) sz.textContent = fmtSize(totalSize);
  const du = $("#st-dur"); if (du) du.textContent = fmtTime(totalDur);

  // bouton supprimer sur chaque ligne
  $$("#lib-list .trow").forEach(row => {
    const del = document.createElement("button");
    del.className = "icon-btn"; del.title = "Supprimer"; del.textContent = "🗑";
    del.style.fontSize = ".85rem";
    del.addEventListener("click", async e => {
      e.stopPropagation();
      const name = row.dataset.name;
      if (!name || !confirm(`Supprimer « ${name} » de la bibliothèque ?`)) return;
      await api("/api/library/" + encodeURIComponent(name), { method: "DELETE" }).catch(() => {});
      const d = getDownloaded();
      for (const k in d) if (d[k] === name) delete d[k];
      LS.set("downloads", d);
      toast("Fichier supprimé");
      refreshLibrary().then(items => applyLibFilter());
    });
    $(".row-side", row).prepend(del);
  });
}

/* ======================================================================
   FAVORIS
   ====================================================================== */
function renderFavs(view) {
  view.innerHTML = `
    <h2 class="section-title">♥ Mes favoris</h2>
    <div class="track-rows" id="favs-rows"></div>`;
  const rows = $("#favs-rows");
  if (!favorites.length) {
    rows.innerHTML = `<div class="empty glass"><div class="big">♥</div>Aucun favori pour l'instant.<br>
      <span style="font-size:.85rem;color:var(--cream-faint)">Cliquez sur le cœur d'un morceau pour le retrouver ici.</span></div>`;
    return;
  }
  rows.innerHTML = favorites.map(f => trowHtml({
    key: f.key, title: f.title, thumb: f.thumb, duration: f.duration,
    duration_str: f.duration_str, url: f.url, name: f.name,
  })).join("");
  bindTrows(rows, favorites.map(f => ({
    key: f.key, title: f.title, thumb: f.thumb, duration: f.duration,
    duration_str: f.duration_str, url: f.url, name: f.name,
  })));
}

/* ======================================================================
   PLAYLISTS INTELLIGENTES
   ====================================================================== */
function renderPlaylists(view, p) {
  if (!p) {
    view.innerHTML = `
      <h2 class="section-title">✨ Playlists intelligentes</h2>
      <div class="smart-grid" id="smart-grid">
        ${smartCard("💾", "Ma bibliothèque", `${libraryItems.length} fichier(s) en local.`, "smart:library")}
        ${smartCard("🕘", "Récemment écoutés", "Reprenez là où vous vous êtes arrêté.", "smart:recent")}
        ${smartCard("🔥", "Plus écoutés", "Vos morceaux les plus passés.", "smart:top")}
        ${smartCard("🎧", "Coups de cœur", `${favorites.length} favori(s).`, "smart:favs")}
        ${smartCard("✨", "Découverte", "Un mélange des tendances du moment.", "smart:discover")}
        ${smartCard("🤝", "Similaires", "Des sons proches de votre écoute actuelle.", "smart:similar")}
      </div>
      <h2 class="section-title">📝 Mes playlists</h2>
      <form class="playlist-form" id="pl-form">
        <input id="pl-name" type="text" placeholder="Nom de la nouvelle playlist…" maxlength="40">
        <button class="wood btn-wood" type="submit">Créer</button>
      </form>
      <div class="chips" id="pl-chips" style="margin-top:16px"></div>`;

    $("#pl-form").addEventListener("submit", e => {
      e.preventDefault();
      const name = $("#pl-name").value.trim();
      if (!name) return;
      if (!customPlaylists[name]) { customPlaylists[name] = []; LS.set("playlists", customPlaylists); }
      toast(`Playlist « ${name} » créée — ajoutez des morceaux avec le bouton ＋`);
      drawPlChips();
    });
    const drawPlChips = () => {
      const names = playlistNames();
      $("#pl-chips").innerHTML = names.length ? names.map(n =>
        `<button class="pl-chip" data-name="${esc(n)}">📝 ${esc(n)} <span class="pl-count">(${customPlaylists[n].length})</span></button>`
      ).join("") : `<span class="pl-empty">Aucune playlist personnalisée pour l'instant.</span>`;
      $$("#pl-chips .pl-chip").forEach(c => c.addEventListener("click", () => {
        location.hash = "#/playlists?p=" + encodeURIComponent("custom:" + c.dataset.name);
      }));
    };
    drawPlChips();
    $$("#smart-grid .smart-card").forEach(c => c.addEventListener("click", () => {
      location.hash = "#/playlists?p=" + encodeURIComponent(c.dataset.smart);
    }));
    return;
  }

  // Vue d'une playlist
  const kind = p.split(":")[0];
  const name = p.split(":").slice(1).join(":");
  view.innerHTML = `
    <p style="margin-top:6px"><a href="#/playlists">↩ Toutes les playlists</a></p>
    <h2 class="section-title" id="pl-title">…</h2>
    <div id="pl-tracks"><div class="loader-wrap"><div class="spinner"></div></div></div>`;

  const load = async () => {
    let tracks = [], title = name;
    if (kind === "library") { title = "💾 Ma bibliothèque"; tracks = libraryItems.map(it => ({
      key: it.url || "local:" + it.name, title: it.title, thumb: it.thumb, duration: it.duration,
      duration_str: it.duration_str, url: it.url || "", name: it.name, local: true })); }
    else if (kind === "recent") { title = "🕘 Récemment écoutés"; tracks = history; }
    else if (kind === "top") {
      title = "🔥 Plus écoutés";
      tracks = [...history].filter(t => (t.count || 0) > 1).sort((a, b) => (b.count || 0) - (a.count || 0));
      if (!tracks.length) tracks = history.slice(0, 10);
    }
    else if (kind === "favs") { title = "🎧 Coups de cœur"; tracks = favorites; }
    else if (kind === "discover") {
      title = "✨ Découverte";
      const r = await api("/api/top?shuffle=1");
      tracks = (r.items || []).slice(0, 15).map(t => ({
        key: t.url, title: t.title, thumb: t.thumb, duration: t.duration,
        duration_str: t.duration_str, url: t.url, name: "" }));
    }
    else if (kind === "similar") {
      const base = currentTrack() || history[0];
      title = "🤝 Similaires à " + (base ? base.title : "…");
      if (base) {
        const words = (base.title || "").split(/\s+/).filter(w => w.length > 3).slice(0, 3).join(" ") || base.title;
        const r = await api("/api/search?q=" + encodeURIComponent(words));
        tracks = (r.items || []).filter(t => t.url !== base.key).slice(0, 12).map(t => ({
          key: t.url, title: t.title, thumb: t.thumb, duration: t.duration,
          duration_str: t.duration_str, url: t.url, name: "" }));
      }
    }
    else if (kind === "custom") {
      title = "📝 " + name;
      tracks = customPlaylists[name] || [];
    }
    const box = $("#pl-tracks");
    $("#pl-title").textContent = title + (tracks.length ? ` · ${tracks.length} morceau(x)` : "");
    if (!tracks.length) {
      box.innerHTML = `<div class="empty glass"><div class="big">🎵</div>Cette playlist est vide.</div>`;
      return;
    }
    box.innerHTML = `<div class="track-rows">${tracks.map(t => trowHtml(t)).join("")}</div>`;
    bindTrows(box, tracks);
    // bouton lire tout
    const playAll = document.createElement("button");
    playAll.className = "wood btn-wood"; playAll.style.margin = "14px 6px";
    playAll.innerHTML = "▶ Lire toute la playlist";
    box.prepend(playAll);
    playAll.addEventListener("click", () => {
      queue = tracks.map(t => ({ ...t }));
      qIndex = 0;
      loadCurrent();
      toast(`Lecture de « ${title} »`);
      $("#queue-panel").hidden = false;
      renderQueue();
    });
    // suppression d'une playlist perso
    if (kind === "custom") {
      const del = document.createElement("button");
      del.className = "ghost"; del.style.margin = "14px 6px";
      del.textContent = "🗑 Supprimer cette playlist";
      del.addEventListener("click", () => {
        if (!confirm(`Supprimer la playlist « ${name} » ?`)) return;
        delete customPlaylists[name];
        LS.set("playlists", customPlaylists);
        location.hash = "#/playlists";
      });
      box.prepend(del);
    }
  };
  load();
}

/* ------------------- Ajout rapide à une playlist ----------------------- */
function promptPlaylist(track) {
  const names = playlistNames();
  if (!names.length) {
    toast("Créez d'abord une playlist dans la section Playlists", "err");
    location.hash = "#/playlists";
    return;
  }
  const box = document.createElement("div");
  box.className = "chips";
  box.innerHTML = names.map(n =>
    `<button class="pl-chip" data-name="${esc(n)}">${esc(n)} <span class="pl-count">(${customPlaylists[n].length})</span></button>`
  ).join("");
  const wrap = document.createElement("div");
  wrap.innerHTML = `<p style="margin-bottom:12px;font-weight:700">Ajouter « ${esc(track.title)} » à :</p>`;
  wrap.appendChild(box);
  const oldBody = $("#modal-body").innerHTML;
  const backdrop = $("#modal-backdrop");
  backdrop.hidden = false;
  $("#modal-body").innerHTML = "";
  $("#modal-body").appendChild(wrap);
  $$("button", box).forEach(b => b.addEventListener("click", () => {
    toggleInPlaylist(b.dataset.name, track);
    backdrop.hidden = true;
    if (detailState) openDetailModal(detailState);
    else $("#modal-body").innerHTML = oldBody;
  }));
}

/* ======================================================================
   DÉTAIL / FORMATS
   ====================================================================== */
let detailState = null;

async function openDetail(url) {
  const backdrop = $("#modal-backdrop");
  backdrop.hidden = false;
  $("#modal-body").innerHTML = `<div class="loader-wrap"><div class="spinner"></div><span>Chargement…</span></div>`;
  let info;
  try { info = await api("/api/page?url=" + encodeURIComponent(url)); }
  catch (e) {
    $("#modal-body").innerHTML = `<div class="empty"><div class="big">⚠️</div>${esc(e.message)}</div>`;
    return;
  }
  if (!info.payload) {
    $("#modal-body").innerHTML = `<div class="empty"><div class="big">🚫</div>Ce contenu n'est pas disponible au téléchargement.</div>`;
    return;
  }
  info.url = url;
  detailState = info;
  openDetailModal(info);
}

async function openDetailModal(info) {
  const dl = getDownloaded()[info.url];
  $("#modal-body").innerHTML = `
    <div class="head">
      <div class="art">${info.thumb ? `<img src="${esc(info.thumb)}" alt="" onerror="this.src='${PLACEHOLDER}'">` : ""}</div>
      <div>
        <h2>${esc(info.title)}</h2>
        <div class="meta-line">
          <span>⏱ ${esc(info.duration_str || "—")}</span>
          <span>🎬 Vidéo disponible</span>
          ${dl ? `<span style="color:#9fe3a8">✓ Dans la bibliothèque</span>` : ""}
        </div>
        <div style="display:flex;gap:8px;margin-top:10px;flex-wrap:wrap">
          <button class="ghost sm" id="dl-fav">${isFav(info.url) ? "♥ Favori" : "♡ Favori"}</button>
          <button class="ghost sm" id="dl-pl">＋ Playlist</button>
        </div>
      </div>
    </div>
    <div class="loader-wrap" id="fmts-loading"><div class="spinner"></div><span>Préparation des formats…</span></div>
    <div class="fmt-list" id="fmts" hidden></div>
    <div class="dl-progress" id="dl-progress" hidden></div>`;

  $("#dl-fav").addEventListener("click", () => {
    toggleFav({ key: info.url, title: info.title, thumb: info.thumb, duration: info.duration, duration_str: info.duration_str, url: info.url });
    $("#dl-fav").textContent = isFav(info.url) ? "♥ Favori" : "♡ Favori";
  });
  $("#dl-pl").addEventListener("click", () => {
    promptPlaylist({ key: info.url, title: info.title, thumb: info.thumb,
      duration: info.duration, duration_str: info.duration_str, url: info.url });
  });

  let formats;
  try {
    formats = await api("/api/formats", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: "payload=" + encodeURIComponent(info.payload)
    });
  } catch (e) {
    $("#fmts-loading").innerHTML = `<span style="color:#ff9c8a">Erreur : ${esc(e.message)}</span>`;
    return;
  }
  $("#fmts-loading").hidden = true;
  if (!formats.formats || !formats.formats.length) {
    $("#fmts").hidden = false;
    $("#fmts").innerHTML = `<div class="empty" style="padding:20px"><div class="big">🕓</div>Aucun format disponible.</div>`;
    return;
  }
  const mp3 = formats.formats.find(f => /MP3/i.test(f.label));
  const mp4v = formats.formats.find(f => /MP4.*video/i.test(f.label));
  const mp4a = formats.formats.find(f => /MP4.*audio/i.test(f.label));
  const savedMp3 = mp3 ? mp3.payload : "";
  info.mp3Payload = savedMp3;

  $("#fmts").hidden = false;
  $("#fmts").innerHTML = formats.formats.map((f, i) => {
    const isMp3 = /MP3/i.test(f.label);
    const isVid = /video/i.test(f.label);
    return `
    <div class="fmt-row">
      <div class="fmt-ico ${isMp3 ? "fmt-mp3" : "fmt-mp4"}">${isMp3 ? "MP3" : isVid ? "🎬" : "MP4"}</div>
      <div class="fmt-info">
        <div class="lbl">${esc(f.label)}</div>
        <div class="sz">${esc(f.size || "—")}</div>
      </div>
      <div class="actions">
        <button class="wood btn-wood sm" data-act="play" data-i="${i}">▶ Écouter</button>
        <button class="wood btn-wood sm" data-act="dl" data-i="${i}">⤓ Télécharger</button>
      </div>
    </div>`;
  }).join("");

  $$("#fmts [data-act=play]").forEach(b => b.addEventListener("click", async () => {
    const f = formats.formats[+b.dataset.i];
    b.disabled = true; b.textContent = "Préparation…";
    try {
      const r = await api("/api/play", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: "payload=" + encodeURIComponent(f.payload)
      });
      if (!r.link) throw new Error("aucun lien de lecture");
      const isVideo = /video/i.test(f.label);
      playRemote({
        key: info.url, title: info.title, thumb: info.thumb,
        duration: info.duration, duration_str: info.duration_str,
        url: info.url, stream: "/stream?u=" + b64url(r.link),
        payload: f.payload, video: isVideo,
      });
      toast(isVideo ? "🎬 Lecture vidéo lancée" : "Lecture lancée : " + info.title);
      if (isVideo) openCinema();
    } catch (e) {
      toast("Impossible de lire : " + e.message, "err");
    } finally { b.disabled = false; b.textContent = "▶ Écouter"; }
  }));

  $$("#fmts [data-act=dl]").forEach(b => b.addEventListener("click", () => {
    const f = formats.formats[+b.dataset.i];
    const ext = /video/i.test(f.label) ? "mp4" : "mp3";
    startDl(info, f.payload, ext);
  }));
}

/* ======================================================================
   TÉLÉCHARGEMENTS
   ====================================================================== */
const DL_KEY = "musikbox.downloads";
function getDownloaded() { return LS.get("downloads", {}); }
function setDownloaded(key, name) { const d = getDownloaded(); d[key] = name; LS.set("downloads", d); }

const activeJobs = {};   // id -> statut courant

async function startDl(info, payload, ext = "mp3") {
  const body = new URLSearchParams({
    payload, ext, url: info.url || "",
    title: info.title, thumb: info.thumb,
    duration: info.duration || 0, duration_str: info.duration_str || ""
  });
  let job;
  try { job = await api("/api/download", { method: "POST", body }); }
  catch (e) { toast("Erreur : " + e.message, "err"); return; }

  if (job.id === "exists") {
    setDownloaded(info.url, job.filename);
    toast("✓ Déjà dans votre bibliothèque !", "ok", 4000);
    refreshLibrary(); renderNavCounts();
    return;
  }

  toast(`⤓ Téléchargement de « ${info.title} »…`);
  // affichage dans la modale si ouverte
  const zone = $("#dl-progress");
  if (zone && !zone.hidden === false) {
    zone.hidden = false;
    zone.innerHTML = `
      <div class="progress-label"><span>⤓ ${esc(ext === "mp4" ? "Vidéo MP4" : "Audio MP3")}</span><span class="dl-pct">0 %</span></div>
      <div class="bar"><div class="bar-fill dl-fill" style="width:0%"></div></div>`;
  }
  pollDl(job.id, info, ext, zone);
}

function pollDl(id, info, ext, zone) {
  activeJobs[id] = { status: "queued", progress: 0 };
  renderNavCounts();
  const timer = setInterval(async () => {
    try {
      const st = await api("/api/download/status?id=" + id);
      activeJobs[id] = st;
      renderNavCounts();
      if (st.status === "done") {
        clearInterval(timer);
        delete activeJobs[id];
        if (info.url) setDownloaded(info.url, st.filename);
        toast(`✓ « ${info.title} » est dans votre bibliothèque !`, "ok", 5000);
        if (zone) zone.hidden = true;
        refreshLibrary();
        if (location.hash.includes("telechargements")) render();
      } else if (st.status === "error") {
        clearInterval(timer);
        delete activeJobs[id];
        toast("Échec : " + (st.error || "inconnu"), "err", 6000);
        if (zone) zone.hidden = true;
      } else {
        const zf = $("#dl-progress .dl-fill"), zp = $("#dl-progress .dl-pct");
        if (zf) zf.style.width = (st.progress || 0) + "%";
        if (zp) zp.textContent = (st.progress || 0) + " %";
      }
      if (location.hash.includes("telechargements") && $("#dl-list")) renderDownloadList();
    } catch (e) { /* continue */ }
  }, 1300);
}

function renderDownloads(view) {
  view.innerHTML = `
    <h2 class="section-title">⤓ Téléchargements</h2>
    <div class="dl-stat-cards">
      <div class="dl-stat glass"><div class="n" id="dl-st-nb">0</div><div class="l">Téléchargés</div></div>
      <div class="dl-stat glass"><div class="n" id="dl-st-size">0</div><div class="l">Espace local</div></div>
      <div class="dl-stat glass"><div class="n" id="dl-st-act">0</div><div class="l">En cours</div></div>
    </div>
    <div class="glass" style="padding:8px 14px;margin-bottom:16px">
      <div class="trow" style="cursor:default">
        <span style="font-size:1.1rem">🔗</span>
        <input id="dl-url" type="text" placeholder="Coller un lien de téléchargement (ou un titre) puis Entrée…"
          style="flex:1;background:none;border:none;outline:none;color:var(--cream);font-size:.92rem">
      </div>
    </div>
    <div id="dl-list"><div class="loader-wrap"><div class="spinner"></div></div></div>`;

  $("#dl-url").addEventListener("keydown", async e => {
    if (e.key !== "Enter") return;
    const v = $("#dl-url").value.trim();
    if (!v) return;
    let url = v;
    if (!/^https?:\/\//i.test(v)) {
      // c'est une recherche → on prend le premier résultat
      try {
        const r = await api("/api/search?q=" + encodeURIComponent(v));
        if (!r.items.length) { toast("Aucun résultat pour cette recherche", "err"); return; }
        url = r.items[0].url;
      } catch (err) { toast("Erreur : " + err.message, "err"); return; }
    }
    openDetail(url);
  });

  renderDownloadList();
}

function renderDownloadList() {
  api("/api/downloads").then(r => {
    const items = r.items || [];
    const box = $("#dl-list");
    if (!box) return;
    const done = items.filter(i => i.status === "done" && i.exists);
    const nb = $("#dl-st-nb"); if (nb) nb.textContent = done.length;
    const sz = $("#dl-st-size"); if (sz) sz.textContent = fmtSize(done.reduce((s, i) => s + (i.size || 0), 0));
    const act = $("#dl-st-act"); if (act) act.textContent = items.filter(i => ["queued", "downloading"].includes(i.status)).length;

    if (!items.length) {
      box.innerHTML = `<div class="empty glass"><div class="big">⤓</div>Aucun téléchargement pour l'instant.</div>`;
      return;
    }
    box.innerHTML = items.map(it => {
      const live = ["queued", "downloading"].includes(it.status);
      const statusTxt = it.status === "done" ? (it.exists ? "✓ Terminé" : "Fichier supprimé") :
        it.status === "error" ? "✗ Échec" : it.status === "queued" ? "En attente…" : `Téléchargement ${it.progress || 0} %`;
      return `
      <div class="glass" style="padding:6px;margin-bottom:10px" data-id="${esc(it.id)}">
        <div class="trow" style="cursor:default">
          <div class="art">${it.thumb ? `<img src="${esc(it.thumb)}" alt="" onerror="this.src='${PLACEHOLDER}'">` : ""}</div>
          <div class="row-meta">
            <div class="row-t">${esc(it.title || "—")} ${it.ext === "mp4" ? '<span class="badge-video">MP4</span>' : ""}</div>
            <div class="row-s">${esc(it.duration_str || "")} · ${esc(it.ext.toUpperCase())} · ${new Date((it.ts || 0) * 1000).toLocaleDateString("fr-FR")} · ${statusTxt}</div>
            ${live ? `<div class="bar" style="margin-top:6px"><div class="bar-fill" style="width:${it.progress || 0}%"></div></div>` : ""}
          </div>
          <div class="row-side">
            ${it.status === "done" && it.exists ? `<button class="wood btn-wood sm dl-listen" data-name="${esc(it.filename)}">▶ Écouter</button>` : ""}
            ${it.status === "error" ? `<span style="font-size:.72rem;color:#ff9c8a;max-width:200px">${esc((it.error || "").slice(0, 60))}</span>` : ""}
            ${it.status === "done" && it.exists ? `<button class="icon-btn dl-del" data-name="${esc(it.filename)}">🗑</button>` : ""}
          </div>
        </div>
      </div>`;
    }).join("");

    $$(".dl-listen", box).forEach(b => b.addEventListener("click", () => {
      const name = b.dataset.name;
      const it = libraryItems.find(x => x.name === name);
      if (it) playLocal(it);
      else { // fichier pas encore dans libraryItems (rafraîchir)
        refreshLibrary().then(() => {
          const it2 = libraryItems.find(x => x.name === name);
          if (it2) playLocal(it2);
        });
      }
    }));
    $$(".dl-del", box).forEach(b => b.addEventListener("click", async () => {
      const name = b.dataset.name;
      if (!confirm(`Supprimer « ${name} » ?`)) return;
      await api("/api/library/" + encodeURIComponent(name), { method: "DELETE" }).catch(() => {});
      toast("Fichier supprimé");
      refreshLibrary(); renderDownloadList();
    }));
  }).catch(() => {
    const box = $("#dl-list");
    if (box) box.innerHTML = `<div class="empty glass"><div class="big">⚠️</div>Erreur de chargement.</div>`;
  });
}

/* ======================================================================
   LECTEUR (audio + vidéo / cinéma)
   ====================================================================== */
const media = $("#media");
media.preload = "auto";

let queue = [], qIndex = -1;

function currentTrack() { return qIndex >= 0 ? queue[qIndex] : null; }

function playTrack(t) {
  const existing = queue.findIndex(x => x.key === t.key);
  if (existing >= 0) qIndex = existing;
  else { queue.push(t); qIndex = queue.length - 1; }
  queue[qIndex] = t;
  media.src = t.stream || t.src || "";
  if (media.src) media.play().catch(() => toast("Cliquez sur ▶ pour lancer la lecture", "err"));
  updatePlayerUi(); renderQueue();
  if (!t.local) notePlay(t);
  $("#player").hidden = false;
}

function resolveAndPlay(t) {
  // 1) local
  const dlName = getDownloaded()[t.key || ""] || t.name;
  if (dlName) {
    const lib = libraryItems.find(x => x.name === dlName);
    if (lib) { playLocal(lib); return; }
  }
  // 2) flux direct
  if (t.stream) { playTrack({ ...t }); return; }
  // 3) payload connu → nouveau lien de lecture
  if (t.payload) {
    api("/api/play", { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: "payload=" + encodeURIComponent(t.payload) })
      .then(r => { if (r.link) playTrack({ ...t, stream: "/stream?u=" + b64url(r.link) });
        else throw new Error("lien expiré"); })
      .catch(() => toast("Lien expiré — relancez depuis la recherche", "err"));
    return;
  }
  // 4) URL page → on prépare la lecture MP3 automatiquement (un clic = ça joue)
  if (t.url) {
    toast("Préparation de la lecture…");
    api("/api/page?url=" + encodeURIComponent(t.url)).then(async info => {
      if (!info.payload) throw new Error("indisponible");
      const fmts = await api("/api/formats", { method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: "payload=" + encodeURIComponent(info.payload) });
      const mp3 = (fmts.formats || []).find(f => /MP3/i.test(f.label));
      if (!mp3) throw new Error("pas de format MP3");
      const r = await api("/api/play", { method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: "payload=" + encodeURIComponent(mp3.payload) });
      if (!r.link) throw new Error("lien indisponible");
      playTrack({ ...t, title: info.title || t.title, thumb: info.thumb || t.thumb,
        duration: info.duration || t.duration, duration_str: info.duration_str || t.duration_str,
        stream: "/stream?u=" + b64url(r.link), payload: mp3.payload });
    }).catch(err => toast("Lecture impossible : " + err.message, "err"));
    return;
  }
  toast("Impossible de lire ce morceau", "err");
}

function playTrackObject(t) {
  if (!t) return;
  if (t.local || t.name) {
    const lib = libraryItems.find(x => x.name === t.name);
    if (lib) { playLocal(lib); return; }
  }
  resolveAndPlay(t);
}

function playRemote(t) { resolveAndPlay(t); }

function playLocal(it) {
  const t = {
    key: it.url || ("local:" + it.name), title: it.title, thumb: it.thumb,
    duration: it.duration || 0, duration_str: it.duration_str || "",
    url: it.url || "", name: it.name, local: true,
    src: "/library/file/" + encodeURIComponent(it.name),
  };
  playTrack(t);
}

function playHistory(t) {
  resolveAndPlay({ key: t.key, title: t.title, thumb: t.thumb, duration: t.duration,
    duration_str: t.duration_str, url: t.url || "", name: t.name || "", payload: t.payload || "" });
}

function nextTrack(auto = false) {
  if (qIndex < queue.length - 1) { qIndex++; loadCurrent(); }
  else if (auto) updatePlayerUi();
}
function prevTrack() {
  if (media.currentTime > 4 || qIndex <= 0) { media.currentTime = 0; return; }
  qIndex--; loadCurrent();
}
function loadCurrent() {
  const t = currentTrack();
  if (!t) return;
  playTrack(t);
}

function updatePlayerUi() {
  const t = currentTrack();
  $("#player").hidden = !t;
  if (!t) return;
  $("#player-title").textContent = t.title;
  const img = $("#player-cover");
  img.src = t.thumb || PLACEHOLDER;
  img.onerror = () => { img.src = PLACEHOLDER; };
  $("#cover-wrap").classList.toggle("playing", !media.paused);
  $("#badge-local").hidden = !t.local;
  $("#badge-stream").hidden = !!t.local || !t.stream && !t.src;
  $("#badge-video").hidden = !t.video;
  $("#btn-cinema").style.opacity = t.video ? 1 : 0.4;
  $("#btn-cinema").title = t.video ? "Cinéma (plein écran vidéo)" : "Vidéo non disponible pour ce flux";
  $("#ico-play").hidden = !media.paused;
  $("#ico-pause").hidden = media.paused;
  const isDl = t.key && getDownloaded()[t.key];
  $("#btn-dl").style.opacity = isDl || t.local ? 0.45 : 1;
  $("#btn-dl").title = isDl || t.local ? "Déjà en local" : "Télécharger en local";
  $("#btn-fav").style.color = isFav(t.key) ? "var(--amber)" : "";
  $$(".trow").forEach(r => r.classList.toggle("playing", r.dataset.key === t.key));
  if ($("#cinema").hidden === false) {
    if (t.video) $("#cinema-title").textContent = t.title;
    else { $("#cinema").hidden = true; if (document.fullscreenElement) document.exitFullscreen().catch(() => {}); }
  }
}

/* --- Cinéma vidéo --- */
function openCinema() {
  const t = currentTrack();
  if (!t || !t.video) { toast("Ce flux n'a pas de vidéo", "err"); return; }
  $("#cinema").hidden = false;
  $("#cinema-title").textContent = t.title;
  const stage = $("#cinema-stage");
  if (stage.requestFullscreen) stage.requestFullscreen().catch(() => {});
}
$("#cinema-close").addEventListener("click", () => {
  if (document.fullscreenElement) document.exitFullscreen().catch(() => {});
  $("#cinema").hidden = true;
});
$("#cinema-fs").addEventListener("click", () => {
  const stage = $("#cinema-stage");
  document.fullscreenElement ? document.exitFullscreen() : stage.requestFullscreen();
});

/* --- Événements média --- */
media.addEventListener("timeupdate", () => {
  $("#t-current").textContent = fmtTime(media.currentTime);
  const pct = media.duration ? (media.currentTime / media.duration) * 100 : 0;
  $("#seek-fill").style.width = pct + "%";
  $("#seek-thumb").style.left = pct + "%";
});
media.addEventListener("loadedmetadata", () => { $("#t-total").textContent = fmtTime(media.duration); });
media.addEventListener("play", () => { $("#cover-wrap").classList.add("playing"); $("#ico-play").hidden = true; $("#ico-pause").hidden = false; });
media.addEventListener("pause", () => { $("#cover-wrap").classList.remove("playing"); $("#ico-play").hidden = false; $("#ico-pause").hidden = true; });
media.addEventListener("ended", () => { nextTrack(true); });
media.addEventListener("error", () => {
  if (currentTrack() && media.src) toast("Lecture impossible pour « " + currentTrack().title + " »", "err");
});
media.addEventListener("dblclick", () => {
  const t = currentTrack();
  if (t && t.video) openCinema();
});

$("#btn-play").addEventListener("click", () => {
  if (!currentTrack()) return;
  media.paused ? media.play() : media.pause();
});
$("#btn-next").addEventListener("click", () => nextTrack());
$("#btn-prev").addEventListener("click", () => prevTrack());

$("#seek-bar").addEventListener("click", e => {
  if (!media.duration) return;
  const r = e.currentTarget.getBoundingClientRect();
  media.currentTime = ((e.clientX - r.left) / r.width) * media.duration;
});
$("#volume").addEventListener("input", e => { media.volume = e.target.value / 100; });

$("#btn-queue").addEventListener("click", () => {
  const p = $("#queue-panel");
  p.hidden = !p.hidden;
  if (!p.hidden) renderQueue();
});
$("#queue-close").addEventListener("click", () => { $("#queue-panel").hidden = true; });
$("#queue-clear").addEventListener("click", () => {
  queue = []; qIndex = -1;
  media.pause(); media.removeAttribute("src");
  $("#player").hidden = true; renderQueue(); updatePlayerUi();
});

$("#btn-cinema").addEventListener("click", () => openCinema());
$("#btn-dl").addEventListener("click", () => {
  const t = currentTrack();
  if (!t || !t.key || getDownloaded()[t.key] || t.local) return;
  openDetail(t.key);
});
$("#btn-fav").addEventListener("click", () => {
  const t = currentTrack();
  if (!t) return;
  toggleFav({ key: t.key, title: t.title, thumb: t.thumb, duration: t.duration, duration_str: t.duration_str, url: t.url || t.key, name: t.name || "" });
});

document.addEventListener("keydown", e => {
  if (e.target.matches("input, textarea, select")) return;
  if (e.code === "Space") { e.preventDefault(); $("#btn-play").click(); }
  if (e.code === "ArrowRight" && !e.shiftKey) nextTrack();
  if (e.code === "ArrowLeft" && !e.shiftKey) prevTrack();
  if (e.key === "Escape" && !$("#cinema").hidden) $("#cinema-close").click();
});

function renderQueue() {
  const list = $("#queue-list");
  $("#queue-count").textContent = queue.length;
  if (!queue.length) { list.innerHTML = `<div style="padding:20px;text-align:center;color:var(--cream-faint);font-size:.85rem">File vide — écoutez un morceau pour l'ajouter.</div>`; return; }
  list.innerHTML = queue.map((t, i) => `
    <div class="queue-item ${i === qIndex ? "current" : ""}" data-i="${i}">
      <span style="color:${i === qIndex ? "var(--amber)" : "var(--cream-faint)"}">${i === qIndex ? "♪" : "·"}</span>
      <span class="q-title">${esc(t.title)}</span>
      <span class="q-dur">${esc(t.duration_str || "")}</span>
      <button class="icon-btn q-del" style="width:26px;height:26px;font-size:.75rem" title="Retirer">✕</button>
    </div>`).join("");
  $$(".queue-item", list).forEach(el => {
    el.addEventListener("click", e => {
      if (e.target.closest(".q-del")) return;
      qIndex = +el.dataset.i; loadCurrent();
    });
    $(".q-del", el).addEventListener("click", e => {
      e.stopPropagation();
      queue.splice(+el.dataset.i, 1);
      if (qIndex >= +el.dataset.i) qIndex = Math.max(0, qIndex - 1);
      if (!queue.length) { qIndex = -1; media.pause(); media.removeAttribute("src"); $("#player").hidden = true; }
      renderQueue(); updatePlayerUi();
    });
  });
}

/* ======================================================================
   MODALE
   ====================================================================== */
$("#modal-close").addEventListener("click", () => { $("#modal-backdrop").hidden = true; });
$("#modal-backdrop").addEventListener("click", e => { if (e.target.id === "modal-backdrop") $("#modal-backdrop").hidden = true; });
document.addEventListener("keydown", e => { if (e.key === "Escape") $("#modal-backdrop").hidden = true; });

/* ======================================================================
   RECHERCHE RAPIDE + SUGGESTIONS
   ====================================================================== */
let sugTimer = null, sugItems = [], sugSel = -1;

function suggest(input, box) {
  clearTimeout(sugTimer);
  const q = input.value.trim();
  if (q.length < 2) { box.hidden = true; return; }
  sugTimer = setTimeout(async () => {
    try {
      const r = await api("/api/suggest?q=" + encodeURIComponent(q));
      sugItems = r.items || [];
      sugSel = -1;
      if (!sugItems.length) { box.hidden = true; return; }
      box.hidden = false;
      box.innerHTML = sugItems.map((s, i) => `<button data-i="${i}" class="${i === 0 ? "sel" : ""}">🔎 ${esc(s)}</button>`).join("");
      $$("button", box).forEach(b => b.addEventListener("click", () => {
        box.hidden = true;
        input.value = b.textContent.replace(/^🔎\s*/, "");
        goSearch(input.value);
      }));
    } catch (e) { box.hidden = true; }
  }, 220);
}

document.addEventListener("keydown", e => {
  const input = document.activeElement;
  if (!input || !input.matches("input[type=search]")) return;
  const box = input.closest(".search")?.querySelector(".suggest");
  if (!box || box.hidden) return;
  if (e.key === "ArrowDown") { e.preventDefault(); moveSug(1, box); }
  else if (e.key === "ArrowUp") { e.preventDefault(); moveSug(-1, box); }
  else if (e.key === "Enter" && sugSel >= 0) {
    e.preventDefault();
    const v = sugItems[sugSel];
    box.hidden = true;
    input.value = v;
    goSearch(v);
  }
});
function moveSug(d, box) {
  const btns = $$("button", box);
  sugSel = (sugSel + d + btns.length) % btns.length;
  btns.forEach((b, i) => b.classList.toggle("sel", i === sugSel));
}

const topInput = $("#search-input"), topSug = $("#suggestions");
topInput.addEventListener("input", () => suggest(topInput, topSug));
topInput.addEventListener("keydown", e => {
  if (e.key === "Enter" && !(sugSel >= 0)) { e.preventDefault(); goSearch(topInput.value); topSug.hidden = true; }
});
$("#search-form").addEventListener("submit", e => { e.preventDefault(); goSearch(topInput.value); topSug.hidden = true; });

$("#burger").addEventListener("click", () => $("#sidebar").classList.toggle("open"));

/* Horloge */
setInterval(() => {
  const el = $("#top-clock");
  if (el) el.textContent = new Date().toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" });
}, 30000);

/* ------------------------------- Init ------------------------------------- */
refreshLibrary();
render();
