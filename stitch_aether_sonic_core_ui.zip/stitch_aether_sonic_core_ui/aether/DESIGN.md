---
name: Aether Sonic
colors:
  surface: '#131317'
  surface-dim: '#131317'
  surface-bright: '#39393d'
  surface-container-lowest: '#0e0e12'
  surface-container-low: '#1b1b1f'
  surface-container: '#1f1f23'
  surface-container-high: '#2a292e'
  surface-container-highest: '#353439'
  on-surface: '#e4e1e7'
  on-surface-variant: '#d5c4ab'
  inverse-surface: '#e4e1e7'
  inverse-on-surface: '#303034'
  outline: '#9e8f78'
  outline-variant: '#514532'
  surface-tint: '#ffba20'
  primary: '#ffdca1'
  on-primary: '#412d00'
  primary-container: '#ffb800'
  on-primary-container: '#6b4c00'
  inverse-primary: '#7c5800'
  secondary: '#ffb693'
  on-secondary: '#561f00'
  secondary-container: '#fe6b00'
  on-secondary-container: '#572000'
  tertiary: '#eed9ff'
  on-tertiary: '#480081'
  tertiary-container: '#dbb6ff'
  on-tertiary-container: '#7600ce'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdea8'
  primary-fixed-dim: '#ffba20'
  on-primary-fixed: '#271900'
  on-primary-fixed-variant: '#5e4200'
  secondary-fixed: '#ffdbcc'
  secondary-fixed-dim: '#ffb693'
  on-secondary-fixed: '#351000'
  on-secondary-fixed-variant: '#7a3000'
  tertiary-fixed: '#efdbff'
  tertiary-fixed-dim: '#dcb8ff'
  on-tertiary-fixed: '#2c0051'
  on-tertiary-fixed-variant: '#6700b5'
  background: '#131317'
  on-background: '#e4e1e7'
  surface-variant: '#353439'
  void-black: '#0e0e12'
  nebula-purple: '#480081'
  stellar-white: '#ffffff'
  holographic-border: rgba(255, 255, 255, 0.2)
typography:
  display-lg:
    fontFamily: Sora
    fontSize: 48px
    fontWeight: '200'
    lineHeight: '1.1'
    letterSpacing: -0.04em
  display-lg-mobile:
    fontFamily: Sora
    fontSize: 36px
    fontWeight: '200'
    lineHeight: '1.1'
    letterSpacing: -0.04em
  headline-md:
    fontFamily: Sora
    fontSize: 24px
    fontWeight: '300'
    lineHeight: '1.2'
    letterSpacing: 0.1em
  body-lg:
    fontFamily: Outfit
    fontSize: 18px
    fontWeight: '300'
    lineHeight: '1.6'
    letterSpacing: 0.2em
  body-md:
    fontFamily: Outfit
    fontSize: 16px
    fontWeight: '300'
    lineHeight: '1.5'
    letterSpacing: 0.01em
  label-caps:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '400'
    lineHeight: '1.0'
    letterSpacing: 0.2em
  time-code:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '400'
    lineHeight: '1.0'
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  atom: 4px
  droplet-gap: 12px
  organic-margin: 24px
  safe-area-top: 64px
  section-padding: 120px
---

## Brand & Style

Aether Sonic is a high-fidelity, immersive audio platform that treats sound as a physical, celestial medium. The brand personality is **mystical, futuristic, and organic**, aiming to evoke a sense of "cosmic calm" and deep focus. 

The visual style is a sophisticated blend of **Glassmorphism** and **Tactile/Skeuomorphic** elements, set against a backdrop of deep space. It utilizes "Holographic Refraction" to create UI elements that feel like liquid light—semi-transparent, glowing, and responding to the environment with volumetric depth. The interface avoids hard edges and traditional flat containers in favor of "droplets" and "orbital" shapes that feel like they are floating in a zero-gravity void.

## Colors

The palette is rooted in a "Cosmic Void" theme. The base is a deep, near-black violet (`#131317`) which serves as the canvas for luminous accents. 

- **Primary (Amber/Gold):** Used for interactive "hot" spots, active tracks, and primary status indicators. It carries a significant glow (`#ffb800`).
- **Secondary (Eclipse Orange):** Used for high-energy interactions and gradients, often paired with Primary to create a "liquid fire" effect (`#fe6b00`).
- **Tertiary (Deep Violet):** Reserved for background nebula effects and subtle holographic tags, reinforcing the space-age theme.
- **Surface Strategy:** Surfaces are rarely solid. They use varying degrees of transparency and blur to create a "holographic" hierarchy rather than a traditional color-based one.

## Typography

The typographic system relies on three distinct voices:
1. **Sora (Headlines/Display):** Used for brand identity and track titles. It is styled with wide letter-spacing and ultra-light weights to appear ethereal and high-tech.
2. **Outfit (Body):** A geometric sans-serif used for metadata (Artist names, descriptions). It should always feel light and airy.
3. **JetBrains Mono (Technical/Labels):** Used for navigation tags, timecodes, and technical data. The monospaced nature conveys precision and a "hud-like" display.

**Styling Note:** Display titles should utilize a `text-glow` effect (soft primary color shadow) to simulate light emission.

## Layout & Spacing

The layout follows a **No Grid / Contextual** approach, centered around a "Sonic Core" (the focal point). Elements orbit the center or are anchored to the edges via glassmorphic shells.

- **Vertical Rhythm:** A heavy top-padding (120px) and bottom-padding (100px) ensure the central visualization remains the undisputed hero.
- **Margins:** Standard 24px side margins for mobile ensure content does not hit the curved edges of the glassmorphic nav bars.
- **Adaptation:** On mobile, controls are clustered in "droplet" groups. On larger screens, these droplets expand into a wider orbital arc around the central core.

## Elevation & Depth

Depth is conveyed through **Glassmorphism** and **Volumetric Glow** rather than traditional Y-axis shadows.

1. **The Void (Base):** The furthest layer, containing the animated shader background.
2. **Holographic Shells:** Elements like buttons and the navigation bar use `backdrop-filter: blur(20px)` with a subtle white inner border to appear as if carved from crystal.
3. **Luminous Indicators:** Active states use a "bloom" effect (extra-diffused glow) that spills over onto surrounding elements.
4. **The Core:** The highest level of depth, utilizing 3D Z-index depth through Three.js/WebGL to create a truly volumetric object that particles can orbit.

## Shapes

The shape language is strictly **Organic and Fluid**.
- **The Droplet:** Small buttons and interactive chips are perfect circles or high-radius rounded rectangles.
- **The Core:** The primary play button uses an irregular, "squishy" border-radius (`40% 60% 70% 30% / 40% 50% 60% 50%`) and a slow rotation to simulate a liquid state.
- **Refraction Edges:** All containers must have a 1px top/left border of 20% white to catch "environmental light."

## Components

### Buttons
- **Droplet Buttons:** Circular, glassmorphic buttons with `backdrop-blur`. They should scale 110% on hover and glow subtly.
- **Core Play Button:** A large, gradient-filled irregular shape with a "counter-rotating" icon to keep the symbol upright while the button body spins.

### Progress & Control
- **Liquid Scrubber:** A 2px track with a "comet-tail" playhead. The playhead is a glowing white circle with an amber shadow and a trailing gradient to suggest movement.
- **Transport Controls:** Clustered in a center-aligned group. The "Next/Previous" buttons use a semi-transparent holographic finish.

### Navigation
- **Floating Dock:** The bottom nav is a floating glass container with a "Luminous Thread"—a subtle 1px line connecting the icons to suggest they are part of a circuit.

### Tags
- **Holographic Tags:** Small, pill-shaped labels with heavy letter-spacing and a `holographic-refraction` background for status indicators like "NOW PLAYING."