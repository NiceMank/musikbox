---
name: Aether Liquid
colors:
  surface: '#131317'
  surface-dim: '#131317'
  surface-bright: '#39393d'
  surface-container-lowest: '#0e0e12'
  surface-container-low: '#1b1b1f'
  surface-container: '#1f1f23'
  surface-container-high: '#2a292e'
  surface-container-highest: '#353439'
  on-surface: '#e4e1e7'
  on-surface-variant: '#d0c5b6'
  inverse-surface: '#e4e1e7'
  inverse-on-surface: '#303034'
  outline: '#998f82'
  outline-variant: '#4d463a'
  surface-tint: '#e3c289'
  primary: '#fffdff'
  on-primary: '#412d02'
  primary-container: '#ffdca1'
  on-primary-container: '#795f30'
  inverse-primary: '#745a2b'
  secondary: '#ffb693'
  on-secondary: '#50240b'
  secondary-container: '#6c3a1f'
  on-secondary-container: '#eba583'
  tertiary: '#fffdff'
  on-tertiary: '#382a47'
  tertiary-container: '#eed9ff'
  on-tertiary-container: '#6d5d7d'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdea7'
  primary-fixed-dim: '#e3c289'
  on-primary-fixed: '#271900'
  on-primary-fixed-variant: '#5a4316'
  secondary-fixed: '#ffdbcb'
  secondary-fixed-dim: '#ffb693'
  on-secondary-fixed: '#341000'
  on-secondary-fixed-variant: '#6c3a1f'
  tertiary-fixed: '#efdbff'
  tertiary-fixed-dim: '#d3bfe4'
  on-tertiary-fixed: '#231531'
  on-tertiary-fixed-variant: '#50415f'
  background: '#131317'
  on-background: '#e4e1e7'
  surface-variant: '#353439'
  local-track-emerald: '#50ffb0'
  local-track-cyan: '#00f5ff'
  online-track-violet: '#bf77ff'
  online-track-cyan: '#00d4ff'
  amber-glow: '#ffba20'
  solar-orange: '#fe6b00'
typography:
  display-lg:
    fontFamily: Sora
    fontSize: 48px
    fontWeight: '200'
    lineHeight: '1.1'
    letterSpacing: -0.04em
  display-lg-mobile:
    fontFamily: Sora
    fontSize: 36px
    fontWeight: '200'
    lineHeight: '1.1'
    letterSpacing: -0.04em
  headline-md:
    fontFamily: Sora
    fontSize: 24px
    fontWeight: '300'
    lineHeight: '1.2'
    letterSpacing: 0.02em
  body-lg:
    fontFamily: Outfit
    fontSize: 18px
    fontWeight: '300'
    lineHeight: '1.6'
    letterSpacing: 0.01em
  body-md:
    fontFamily: Outfit
    fontSize: 16px
    fontWeight: '300'
    lineHeight: '1.5'
    letterSpacing: 0.01em
  label-caps:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '400'
    lineHeight: '1.0'
    letterSpacing: 0.2em
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  atom: 4px
  droplet-gap: 12px
  organic-margin: 24px
  safe-area-top: 64px
---

## Brand & Style

This design system is defined by the concept of "Liquid Light"—a living, breathing interface that prioritizes organic movement over static structure. It is designed for an immersive "Song Universe" where music is not just heard but felt through a reactive, ethereal environment. 

The style is **Organic Futurism mixed with Glassmorphism**. It rejects the industrial rigidity of traditional UI, opting instead for fluid, non-rectangular shapes that exhibit "surface tension." The emotional response is one of calm immersion, deep focus, and high-tech wonder. Visuals utilize subsurface scattering (inner glows), holographic refraction (edge light-splitting), and liquid-like transitions to create a tactile, three-dimensional volume within the screen's dark void.

## Colors

The color system operates on a deep **Cosmic Void** (Neutral) foundation. Interactive elements are not flat; they are light-sources.

- **Primary (Amber/Gold):** Represents the "warmth" of sound and core focal points.
- **Secondary (Solar Orange):** Signifies energy, momentum, and peak intensity.
- **Tertiary (Ether Violet):** Used for background "nebula" glows and cool-toned metadata.
- **Semantic Track Colors:** 
    - **Local Tracks:** A gradient fusion of **Emerald** and **Cyan**.
    - **Online Tracks:** A gradient fusion of **Violet** and **Cyan**.

Avoid flat fills. All chromatic colors must be implemented as luminous gradients or glows with a minimum of 20% opacity at their softest edges.

## Typography

Typography should appear "etched in light." 

- **Sora** is the primary display face, used for headlines to convey a futuristic, geometric precision. Keep weights between 200 and 300.
- **Outfit** provides a humanistic, soft contrast for body text, echoing the organic nature of the UI shapes.
- **JetBrains Mono** is reserved for technical data (bitrates, timestamps) to evoke a scientific, precision-instrument feel.

**Rendering Note:** All text elements should have a subtle `0.5px` to `1px` outer glow in their respective text color to simulate light emission.

## Layout & Spacing

This system utilizes a **No Grid** philosophy, favoring **Radial Composition**.

1.  **Central Gravity:** Elements gravitate toward a central focal point, typically the album art "droplet."
2.  **Droplet Gap:** Maintain a 12px "buffer" between elements to ensure their glow-fields do not muddy one another.
3.  **Organic Margins:** A strict 24px safety margin from the screen edge ensures no element feels constrained by the device bezel.
4.  **Z-Axis Depth:** Background elements should be scaled to 80% and blurred, creating a sense of infinite vertical space.

## Elevation & Depth

Elevation is conveyed through **Volumetric Density** rather than traditional drop shadows.

- **Subsurface Scattering:** Use inner-to-outer radial gradients to make elements look like semi-translucent liquids illuminated from within.
- **Backdrop Refraction:** High-elevation containers (like the active player) use a 30px+ backdrop blur and a subtle chromatic aberration (0.5px color shift) at the edges.
- **Parallax Dust:** Implement 1-3px floating micro-particles at 20% opacity that move with device motion sensors to define the physical distance between UI layers.

## Shapes

The shape language is strictly **A-rectangular**. 

The design utilizes "Pill-shaped" (Level 3) as a foundation but encourages **Variable Radius** application. Elements should never be perfect geometric primitives; apply slight "wobbles" or non-uniform corners to create organic, egg-like or kidney-bean shapes. When elements are grouped, their backgrounds should visually "melt" into one another like liquid wax rather than maintaining hard boundaries.

## Components

- **The Core (Play Button):** A morphing amber droplet with a pulsing inner glow. It must physically "compress" on touch.
- **Aura Chips:** Floating orbs of light for genres/tags. These have no borders—only a soft Ether Violet glow.
- **Liquid Scrubber:** A luminous path that thickens at the current playhead position. The playhead is a bright gold micro-particle with a faint "comet tail" trail.
- **Glass List Items:** Soft, translucent capsules floating in the void. Interaction triggers a liquid ripple effect that spreads across the entire list.
- **Orbital Inputs:** Single-line holographic paths. The line glows brighter when active, and the label/placeholder projects above the line as a faint holographic glow.
- **Holographic Clusters:** Groups of information are contained within a shared refractive blur field with no hard edges, creating a "fog" that separates them from the background.